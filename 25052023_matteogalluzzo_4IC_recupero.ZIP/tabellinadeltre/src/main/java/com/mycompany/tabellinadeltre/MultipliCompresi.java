/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;

public class MultipliCompresi {
    public void multiplicomprei(){
        System.out.println("esercizio che stampa i multipli di un numero intero A compresso tra due numeri inseriti interi X e Y");
        Scanner scanner = new Scanner(System.in);

        // Chiedi all'utente di inserire il numero A
        System.out.print("Inserisci un numero A: ");
        int numeroA = scanner.nextInt();

        // Chiedi all'utente di inserire i numeri X e Y
        System.out.print("Inserisci il numero X: ");
        int numeroX = scanner.nextInt();

        System.out.print("Inserisci il numero Y: ");
        int numeroY = scanner.nextInt();

        // Stampa i multipli di A compresi tra X e Y
        System.out.println("I multipli di " + numeroA + " compresi tra " + numeroX + " e " + numeroY + " sono:");

        for (int i = numeroX; i <= numeroY; i++) {
            if (i % numeroA == 0) {
                System.out.println(i);
            }
        }
    }
    public static void main(String[] args) {
        
            }
        }



