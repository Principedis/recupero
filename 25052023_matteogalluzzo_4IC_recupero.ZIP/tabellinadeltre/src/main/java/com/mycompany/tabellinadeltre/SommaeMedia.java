/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;
/**
 *
 * @author Matteo Galluzzo
 */
public class SommaeMedia {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Inserisci il numero di elementi: ");
        int N = scanner.nextInt();
        
        if (N <= 0) {
            System.out.println("Il numero di elementi deve essere maggiore di 0.");
            return;
        }
        
        int somma = 0;
        
        for (int i = 1; i <= N; i++) {
            System.out.print("Inserisci il numero " + i + ": ");
            int numero = scanner.nextInt();
            somma += numero;
        }
        
        double media = (double) somma / N;
        
        System.out.println("La somma dei numeri inseriti è: " + somma);
        System.out.println("La media dei numeri inseriti è: " + media);
    }
}

