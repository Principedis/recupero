/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;
/**
 *
 * @author Matteo Galluzzo
 */
public class SommaPariProdottoDispari {
    public void prodotto(){
         Scanner scanner = new Scanner(System.in);
        
        System.out.print("Inserisci il numero di elementi: ");
        int N = scanner.nextInt();
        
        int sommaPari = 0;
        int prodottoDispari = 1;
        
        for (int i = 1; i <= N; i++) {
            System.out.print("Inserisci il numero " + i + ": ");
            int numero = scanner.nextInt();
            
            if (numero % 2 == 0) {
                sommaPari += numero;
            } else {
                prodottoDispari *= numero;
            }
        }
        
        System.out.println("La somma dei numeri pari è: " + sommaPari);
        System.out.println("Il prodotto dei numeri dispari è: " + prodottoDispari);
    }
    public static void main(String[] args) {
       
    }
}

