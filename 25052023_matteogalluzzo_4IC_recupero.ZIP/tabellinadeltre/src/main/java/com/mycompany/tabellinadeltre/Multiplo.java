/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;

public class Multiplo {
    public void multiplo(){
        System.out.print("Inserisci un dato in input un numero intero determini se è multiplo di un numero X anch'esso intero e richiesto in input ");
        Scanner scanner = new Scanner(System.in);
        
        // Chiedi all'utente di inserire il numero intero da controllare
        System.out.print("Inserisci un numero intero: ");
        int numero = scanner.nextInt();
        
        // Chiedi all'utente di inserire il numero X per verificare se il numero è multiplo di X
        System.out.print("Inserisci un numero intero X: ");
        int X = scanner.nextInt();
        
        // Verifica se il numero è multiplo di X
        if (numero % X == 0) {
            System.out.println(numero + " è multiplo di " + X);
        } else {
            System.out.println(numero + " non è multiplo di " + X);
        }
    }
    public static void main(String[] args) {
        
    }

    Multiplo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

