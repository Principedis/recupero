/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;
/**
 *
 * @author Matteo Galluzzo
 */
public class contanumeriminori {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int count = 0;
        
        System.out.println("Inserisci 11 numeri:");
        
        for (int i = 1; i <= 11; i++) {
            System.out.print("Numero " + i + ": ");
            int num = scanner.nextInt();
            
            if (num < 10) {
                count++;
            }
        }
        
        System.out.println("Il numero di numeri minori di 10 inseriti è: " + count);
    }
}

