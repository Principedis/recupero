/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;

public class MediaAritmetica {
    public void midearitmetica(){
        System.out.print("Inserisci i dati in input N valori interi positivi, calcoli la media aritmetica ");
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Inserisci il numero di elementi: ");
        int N = scanner.nextInt();
        
        if (N <= 0) {
            System.out.println("Il numero di elementi deve essere maggiore di 0.");
            return;
        }
        
        int somma = 0;
        
        for (int i = 1; i <= N; i++) {
            System.out.print("Inserisci il numero " + i + ": ");
            int numero = scanner.nextInt();
            
            if (numero <= 0) {
                System.out.println("I numeri devono essere positivi.");
                return;
            }
            
            somma += numero;
        }
        // Calcolo della media aritmetica
        double media = (double) somma / N;
        
        System.out.println("La media aritmetica dei numeri inseriti è: " + media);
    }

    public static void main(String[] args) {
        
    }
}
