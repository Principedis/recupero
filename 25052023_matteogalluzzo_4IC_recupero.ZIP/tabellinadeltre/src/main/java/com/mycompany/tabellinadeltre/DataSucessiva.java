/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;

public class DataSucessiva {
    public void datasucessiva(){
        System.out.println("esercizio che stampa il giorno successivo");
        Scanner scanner = new Scanner(System.in);
        
        // Chiedi all'utente di inserire il giorno, il mese e l'anno
        System.out.print("Inserisci il giorno: ");
        int giorno = scanner.nextInt();
        
        System.out.print("Inserisci il mese: ");
        int mese = scanner.nextInt();
        
        System.out.print("Inserisci l'anno: ");
        int anno = scanner.nextInt();
        
        // Verifica il mese e il giorno successivo
        int giornoSuccessivo = giorno;
        int meseSuccessivo = mese;
        int annoSuccessivo = anno;
        
        if (mese == 2) { // Febbraio
            if (giorno < 28) {
                giornoSuccessivo = giorno + 1;
            } else {
                giornoSuccessivo = 1;
                meseSuccessivo = 3; // Passaggio a Marzo
            }
        } else if (mese == 12) { // Dicembre
            if (giorno < 31) {
                giornoSuccessivo = giorno + 1;
            } else {
                giornoSuccessivo = 1;
                meseSuccessivo = 1; // Passaggio a Gennaio
                annoSuccessivo = anno + 1; // Incremento dell'anno
            }
        } else { // Altri mesi
            if (giorno < 31) {
                giornoSuccessivo = giorno + 1;
            } else {
                giornoSuccessivo = 1;
                meseSuccessivo = mese + 1; // Passaggio al mese successivo
            }
        }
        
        // Stampa la data successiva
        System.out.println("La data successiva è: " + giornoSuccessivo + "/" + meseSuccessivo + "/" + annoSuccessivo);
    }
    public static void main(String[] args) {
        
    }
}    

