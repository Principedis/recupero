/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;

public class Multipli {
    public void multi(){
        System.out.println("esercizio che stampa i primi 12 multipli di un numero inserito dal esterno");
        Scanner scanner = new Scanner(System.in);
        
        // Chiedi all'utente di inserire il numero
        System.out.print("Inserisci un numero: ");
        int numero = scanner.nextInt();
        
        // Stampa i primi 12 multipli del numero
        System.out.println("I primi 12 multipli di " + numero + " sono:");
        
        for (int i = 1; i <= 12; i++) {
            int multiplo = numero * i;
            System.out.println(multiplo);
        }
    }
    public static void main(String[] args) {
        
        }
    }


