/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;

public class PariDispari {
    public void paridispari(){
        System.out.println("esercizio che controlla se tra i numeri ricevuti in input sono più i pari o i dispari");
        Scanner scanner = new Scanner(System.in);

        // Chiedi all'utente di inserire i numeri
        System.out.print("Inserisci una sequenza di numeri separati da spazio: ");
        String input = scanner.nextLine();
        String[] numeriStringa = input.split(" ");

        int pari = 0;
        int dispari = 0;

        // Controlla se i numeri sono pari o dispari
        for (String numeroStringa : numeriStringa) {
            int numero = Integer.parseInt(numeroStringa);

            if (numero % 2 == 0) {
                pari++;
            } else {
                dispari++;
            }
        }

        // Stampa il risultato
        if (pari > dispari) {
            System.out.println("Ci sono più numeri pari.");
        } else if (pari < dispari) {
            System.out.println("Ci sono più numeri dispari.");
        } else {
            System.out.println("Ci sono lo stesso numero di numeri pari e dispari.");
        }
    }
    public static void main(String[] args) {
        
        }
    }


