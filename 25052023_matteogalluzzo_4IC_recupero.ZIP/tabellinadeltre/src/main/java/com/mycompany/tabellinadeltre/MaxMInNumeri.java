/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;
/**
 *
 * @author Matteo Galluzzo
 */
public class MaxMInNumeri {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Inserisci il numero di elementi: ");
        int N = scanner.nextInt();
        
        if (N <= 0) {
            System.out.println("Il numero di elementi deve essere maggiore di 0.");
            return;
        }
        
        System.out.print("Inserisci il numero 1: ");
        int numero = scanner.nextInt();
        int minimo = numero;
        int massimo = numero;
        
        for (int i = 2; i <= N; i++) {
            System.out.print("Inserisci il numero " + i + ": ");
            numero = scanner.nextInt();
            
            if (numero < minimo) {
                minimo = numero;
            }
            
            if (numero > massimo) {
                massimo = numero;
            }
        }
        
        System.out.println("Il numero minimo inserito è: " + minimo);
        System.out.println("Il numero massimo inserito è: " + massimo);
    }
} 

