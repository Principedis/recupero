/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;

public class ContaStudenti {
    public void conta(){
        System.out.println("esercizio che stabilisce quanti sono insufficienti e quanti sono sufficienti");
        Scanner scanner = new Scanner(System.in);      //Scanner per leggere l'input dell'utente.
        
        // Chiedi all'utente di inserire il numero di studenti
        System.out.print("Inserisci il numero di studenti: ");
        int numeroStudenti = scanner.nextInt();
        
        // Inizializza le variabili per contare gli studenti insufficienti e sufficienti
        int insufficienti = 0;
        int sufficienti = 0;
        
        // Ciclo for per ottenere i voti di ogni studente
        for (int i = 1; i <= numeroStudenti; i++) {
            // Chiedi all'utente di inserire il voto dello studente corrente
            System.out.print("Inserisci il voto dello studente " + i + ": ");
            int voto = scanner.nextInt();
            
            // Verifica se il voto è inferiore a 60 e aggiorna le variabili
            if (voto < 6) {
                insufficienti++;
            } else {
                sufficienti++;
            }
        }
        
        // Stampa il numero di studenti insufficienti e sufficienti
        System.out.println("Numero di studenti insufficienti: " + insufficienti);
        System.out.println("Numero di studenti sufficienti: " + sufficienti);

    }
    public static void main(String[] args) {
            }
}
