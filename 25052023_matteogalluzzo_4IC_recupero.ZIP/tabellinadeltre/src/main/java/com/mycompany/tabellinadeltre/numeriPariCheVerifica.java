/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;
/**
 *
 * @author Matteo Galluzzo
 */
public class numeriPariCheVerifica {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Inserisci il valore di n: ");
        int n = scanner.nextInt();
        
        if (n > 0) {
            System.out.println("I primi " + n + " numeri pari sono:");
            
            for (int i = 1; i <= n; i++) {
                int numeroPari = 2 * i;
                System.out.println(numeroPari);
            }
        } else {
            System.out.println("Il valore di n deve essere maggiore di 0.");
        }
    }
}

