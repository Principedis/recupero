/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;

/**
 *
 * @author Matteo Galluzzo
 */
public class MultiplidiCinque {
    public static void main(String[] args) {
        System.out.println("I multipli di 5 compresi tra 1 e 100 sono:");
        
        for (int i = 1; i <= 100; i++) {
            if (i % 5 == 0) {
                System.out.println(i);
            }
        }
    }
}

