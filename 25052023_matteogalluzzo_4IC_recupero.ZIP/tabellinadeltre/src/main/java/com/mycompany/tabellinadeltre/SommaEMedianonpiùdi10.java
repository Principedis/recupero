/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;

public class SommaEMedianonpiùdi10 {
    public void media() {
        System.out.println("esercizio che dati in input una sequenza di numeri chiusa dallo 0 si determini la loro somma e la loro media, non sarà possibile inserire più di 10 numeri");
        Scanner scanner = new Scanner(System.in);
        
        // Dichiarazione delle variabili per la somma, la media e il contatore
        int somma = 0;
        double media;
        int contatore = 0;
        
        // Ciclo while per ottenere la sequenza di numeri
        System.out.println("Inserisci una sequenza di numeri (0 per terminare):");
        int numero = scanner.nextInt();
        
        while (numero != 0 && contatore < 10) {
            // Aggiorna la somma
            somma += numero;
            
            // Aggiorna il contatore
            contatore++;
            
            // Ottieni il prossimo numero
            numero = scanner.nextInt();
        }
        
        // Calcola la media
        media = (double) somma / contatore;
        
        // Stampa la somma e la media
        System.out.println("La somma dei numeri è: " + somma);
        System.out.println("La media dei numeri è: " + media);
    
}
    public static void main(String[] args) {
        
    }
}  

