/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tabellinadeltre;
import java.util.Scanner;

/**
 *
 * @author Matteo Galluzzo
 */
public class sommanumeri {
    public static void main(String[] args) {
        int somma = 0;
        Scanner scanner = new Scanner(System.in);
        
        while (somma < 100) {
            System.out.print("Inserisci un numero: ");
            int numero = scanner.nextInt();
            somma += numero;
        }
        
        System.out.println("La somma è diventata >= 100. Somma totale: " + somma);
    }
}

